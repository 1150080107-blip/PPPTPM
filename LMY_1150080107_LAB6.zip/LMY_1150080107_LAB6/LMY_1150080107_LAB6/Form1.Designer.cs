﻿namespace LMY_1150080107_LAB6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTenNXB = new TextBox();
            txtDiaChi = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtMaNXB = new TextBox();
            lsvDanhSach = new ListView();
            label5 = new Label();
            txtMaNXB2 = new TextBox();
            txtTenNXB2 = new TextBox();
            txtDiaChi2 = new TextBox();
            label4 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            groupBox1 = new GroupBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtTenNXB
            // 
            txtTenNXB.Location = new Point(158, 199);
            txtTenNXB.Name = "txtTenNXB";
            txtTenNXB.Size = new Size(150, 31);
            txtTenNXB.TabIndex = 2;
            // 
            // txtDiaChi
            // 
            txtDiaChi.Location = new Point(158, 259);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(150, 31);
            txtDiaChi.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(53, 146);
            label1.Name = "label1";
            label1.Size = new Size(81, 25);
            label1.TabIndex = 4;
            label1.Text = " Mã NXB";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(53, 265);
            label2.Name = "label2";
            label2.Size = new Size(65, 25);
            label2.TabIndex = 5;
            label2.Text = "Địa chỉ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(53, 205);
            label3.Name = "label3";
            label3.Size = new Size(77, 25);
            label3.TabIndex = 6;
            label3.Text = "Tên NXB";
            label3.Click += label3_Click;
            // 
            // txtMaNXB
            // 
            txtMaNXB.Location = new Point(158, 140);
            txtMaNXB.Name = "txtMaNXB";
            txtMaNXB.Size = new Size(150, 31);
            txtMaNXB.TabIndex = 1;
            txtMaNXB.TextChanged += txtMaNXB_TextChanged;
            // 
            // lsvDanhSach
            // 
            lsvDanhSach.FullRowSelect = true;
            lsvDanhSach.GridLines = true;
            lsvDanhSach.Location = new Point(53, 12);
            lsvDanhSach.Name = "lsvDanhSach";
            lsvDanhSach.Size = new Size(363, 122);
            lsvDanhSach.TabIndex = 8;
            lsvDanhSach.UseCompatibleStateImageBehavior = false;
            lsvDanhSach.SelectedIndexChanged += lsvDanhSach_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(105, 43);
            label5.Name = "label5";
            label5.Size = new Size(266, 25);
            label5.TabIndex = 9;
            label5.Text = " DANH SÁCH NHÀ XUẤT BẢN   ";
            // 
            // txtMaNXB2
            // 
            txtMaNXB2.Location = new Point(143, 119);
            txtMaNXB2.Name = "txtMaNXB2";
            txtMaNXB2.Size = new Size(150, 31);
            txtMaNXB2.TabIndex = 10;
            // 
            // txtTenNXB2
            // 
            txtTenNXB2.Location = new Point(143, 178);
            txtTenNXB2.Name = "txtTenNXB2";
            txtTenNXB2.Size = new Size(150, 31);
            txtTenNXB2.TabIndex = 11;
            txtTenNXB2.TextChanged += textBox2_TextChanged;
            // 
            // txtDiaChi2
            // 
            txtDiaChi2.Location = new Point(143, 238);
            txtDiaChi2.Name = "txtDiaChi2";
            txtDiaChi2.Size = new Size(150, 31);
            txtDiaChi2.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(493, 141);
            label4.Name = "label4";
            label4.Size = new Size(0, 25);
            label4.TabIndex = 13;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(39, 122);
            label6.Name = "label6";
            label6.Size = new Size(81, 25);
            label6.TabIndex = 14;
            label6.Text = " Mã NXB";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(51, 238);
            label7.Name = "label7";
            label7.Size = new Size(65, 25);
            label7.TabIndex = 15;
            label7.Text = "Địa chỉ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(39, 178);
            label8.Name = "label8";
            label8.Size = new Size(77, 25);
            label8.TabIndex = 16;
            label8.Text = "Tên NXB";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(txtMaNXB2);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(txtTenNXB2);
            groupBox1.Controls.Add(txtDiaChi2);
            groupBox1.ImeMode = ImeMode.Hiragana;
            groupBox1.Location = new Point(422, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(336, 383);
            groupBox1.TabIndex = 17;
            groupBox1.TabStop = false;
            groupBox1.Text = "LÊ MY_THÔNG TIN NHẬP DỮ LIỆU";
            groupBox1.UseCompatibleTextRendering = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(lsvDanhSach);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtDiaChi);
            Controls.Add(txtTenNXB);
            Controls.Add(txtMaNXB);
            Name = "Form1";
            Text = "LÊ MY_1150080107_TẠO DANH SÁCH";
            Load += Form1_Load;
            Click += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtTenNXB;
        private TextBox txtDiaChi;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtMaNXB;
        private ListView lsvDanhSach;
        private Label label5;
        private TextBox txtMaNXB2;
        private TextBox txtTenNXB2;
        private TextBox txtDiaChi2;
        private Label label4;
        private Label label6;
        private Label label7;
        private Label label8;
        private GroupBox groupBox1;
    }
}
