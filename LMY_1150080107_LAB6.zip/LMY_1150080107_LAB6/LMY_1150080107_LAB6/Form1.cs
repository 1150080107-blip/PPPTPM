﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows.Forms;

namespace LMY_1150080107_LAB6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // 🔗 Chuỗi kết nối đến CSDL LocalDB
        string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog=QuanLyBanSach;Integrated Security=True";

        SqlConnection? sqlCon = null;

        // 📡 Mở kết nối
        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        // 🔒 Đóng kết nối
        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // 📋 Hiển thị danh sách NXB ra ListView
        private void HienThiDanhSachNXB2()
        {
            MoKetNoi();

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiNXB"; // tên thủ tục
            sqlCmd.Connection = sqlCon;

            SqlDataReader reader = sqlCmd.ExecuteReader();

            lsvDanhSach2.Items.Clear();

            while (reader.Read())
            {
                string maNXB = reader.GetString(0);
                string tenNXB = reader.GetString(1);
                string diaChi = reader.GetString(2);

                ListViewItem lvi = new ListViewItem(maNXB);
                lvi.SubItems.Add(tenNXB);
                lvi.SubItems.Add(diaChi);

                lsvDanhSach2.Items.Add(lvi);
            }

            reader.Close();
            DongKetNoi();
        }

        // 📖 Hiển thị thông tin chi tiết 1 NXB
        private void HienThiThongTinNXBTheoMa2(string maNXB)
        {
            MoKetNoi();

            SqlCommand sqlCmd = new SqlCommand();
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.CommandText = "HienThiChiTietNXB";
            sqlCmd.Connection = sqlCon;

            SqlParameter parMaNXB = new SqlParameter("@maNXB", SqlDbType.Char);
            parMaNXB.Value = maNXB;
            sqlCmd.Parameters.Add(parMaNXB);

            SqlDataReader reader = sqlCmd.ExecuteReader();

            txtMaNXB2.Text = txtTenNXB2.Text = txtDiaChi2.Text = "";

            if (reader.Read())
            {
                txtMaNXB2.Text = reader.GetString(0);
                txtTenNXB2.Text = reader.GetString(1);
                txtDiaChi2.Text = reader.GetString(2);
            }

            reader.Close();
            DongKetNoi();
        }

        // ⚡ Khi Form load → hiển thị danh sách
        private void Form1_Load(object sender, EventArgs e)
        {
            // Cấu hình cột cho ListView (nếu chưa có)
            lsvDanhSach2.View = View.Details;
            lsvDanhSach2.FullRowSelect = true;
            lsvDanhSach2.GridLines = true;

            lsvDanhSach2.Columns.Add("Mã NXB", 100);
            lsvDanhSach2.Columns.Add("Tên NXB", 180);
            lsvDanhSach2.Columns.Add("Địa chỉ", 200);

            HienThiDanhSachNXB2();
        }

        // 📌 Khi chọn dòng trong ListView → hiện chi tiết
        private void lsvDanhSach2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lsvDanhSach2.SelectedItems.Count == 0)
                return;

            ListViewItem lvi = lsvDanhSach2.SelectedItems[0];
            string maNXB = lvi.SubItems[0].Text;
            HienThiThongTinNXBTheoMa2(maNXB);
        }

        // ➕ Thêm nhà xuất bản mới
        private void btnThemNXB2_Click(object sender, EventArgs e)
        {
            try
            {
                MoKetNoi();

                SqlCommand sqlCmd = new SqlCommand();
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.CommandText = "ThemDuLieu"; // tên thủ tục SQL để thêm
                sqlCmd.Connection = sqlCon;

                SqlParameter parMaNXB = new SqlParameter("@maNXB", SqlDbType.Char);
                SqlParameter parTenNXB = new SqlParameter("@tenNXB", SqlDbType.NVarChar);
                SqlParameter parDiaChi = new SqlParameter("@diaChi", SqlDbType.NVarChar);

                parMaNXB.Value = txtMaNXB2.Text.Trim();
                parTenNXB.Value = txtTenNXB2.Text.Trim();
                parDiaChi.Value = txtDiaChi2.Text.Trim();

                sqlCmd.Parameters.Add(parMaNXB);
                sqlCmd.Parameters.Add(parTenNXB);
                sqlCmd.Parameters.Add(parDiaChi);

                int kq = sqlCmd.ExecuteNonQuery();
                if (kq > 0)
                {
                    MessageBox.Show("✅ Thêm dữ liệu thành công!");
                    HienThiDanhSachNXB2();
                    txtMaNXB2.Text = txtTenNXB2.Text = txtDiaChi2.Text = "";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("❌ Lỗi khi thêm dữ liệu: " + ex.Message);
            }
            finally
            {
                DongKetNoi();
            }
        }
    }
}
