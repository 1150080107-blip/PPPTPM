﻿namespace LABB2_lemy
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label1 = new Label();
            textBox1 = new TextBox();
            groupBox2 = new GroupBox();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            groupBox3 = new GroupBox();
            button1 = new Button();
            textBox2 = new TextBox();
            button2 = new Button();
            numericUpDown1 = new NumericUpDown();
            numericUpDown2 = new NumericUpDown();
            numericUpDown3 = new NumericUpDown();
            groupBox4 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Location = new Point(12, 78);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(787, 67);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Tên khách hàng";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(198, 27);
            label1.Name = "label1";
            label1.Size = new Size(306, 25);
            label1.TabIndex = 1;
            label1.Text = "PHÒNG KHÁM ĐA KHOA HẢI ÂU";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(161, 20);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(454, 31);
            textBox1.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(numericUpDown3);
            groupBox2.Controls.Add(numericUpDown2);
            groupBox2.Controls.Add(numericUpDown1);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(checkBox5);
            groupBox2.Controls.Add(checkBox4);
            groupBox2.Controls.Add(checkBox3);
            groupBox2.Controls.Add(checkBox2);
            groupBox2.Controls.Add(checkBox1);
            groupBox2.Location = new Point(12, 151);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(787, 168);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Dịch vụ tại phòng khám";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(108, 30);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(138, 29);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Lấy cao răng";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(108, 54);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(153, 29);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "Tẩy trắng răng";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(108, 80);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(111, 29);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "Hàn răng";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Location = new Point(108, 105);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(98, 29);
            checkBox4.TabIndex = 3;
            checkBox4.Text = "Bẻ răng";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Location = new Point(108, 133);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(108, 29);
            checkBox5.TabIndex = 4;
            checkBox5.Text = "Bọc răng";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(440, 28);
            label2.Name = "label2";
            label2.Size = new Size(127, 25);
            label2.TabIndex = 5;
            label2.Text = "50000D/2ham";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(440, 58);
            label3.Name = "label3";
            label3.Size = new Size(135, 25);
            label3.TabIndex = 6;
            label3.Text = "100000d/2ham";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(440, 84);
            label4.Name = "label4";
            label4.Size = new Size(136, 25);
            label4.TabIndex = 7;
            label4.Text = "100000d/1rang";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(440, 109);
            label5.Name = "label5";
            label5.Size = new Size(126, 25);
            label5.TabIndex = 8;
            label5.Text = "10000d/1rang";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(440, 134);
            label6.Name = "label6";
            label6.Size = new Size(146, 25);
            label6.TabIndex = 9;
            label6.Text = "1000000d/1rang";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button2);
            groupBox3.Controls.Add(textBox2);
            groupBox3.Controls.Add(button1);
            groupBox3.Location = new Point(12, 325);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(787, 150);
            groupBox3.TabIndex = 3;
            groupBox3.TabStop = false;
            groupBox3.Text = "Chức năng";
            // 
            // button1
            // 
            button1.Location = new Point(74, 35);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 0;
            button1.Text = "Tính tiền";
            button1.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(216, 38);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(285, 31);
            textBox2.TabIndex = 1;
            // 
            // button2
            // 
            button2.Location = new Point(575, 38);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 2;
            button2.Text = "Thoát";
            button2.UseVisualStyleBackColor = true;
            // 
            // numericUpDown1
            // 
            numericUpDown1.Location = new Point(636, 78);
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(51, 31);
            numericUpDown1.TabIndex = 10;
            // 
            // numericUpDown2
            // 
            numericUpDown2.Location = new Point(636, 107);
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(51, 31);
            numericUpDown2.TabIndex = 11;
            // 
            // numericUpDown3
            // 
            numericUpDown3.Location = new Point(636, 137);
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new Size(51, 31);
            numericUpDown3.TabIndex = 12;
            // 
            // groupBox4
            // 
            groupBox4.BackColor = Color.Green;
            groupBox4.Controls.Add(label1);
            groupBox4.Location = new Point(18, 10);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(770, 71);
            groupBox4.TabIndex = 4;
            groupBox4.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "LêMy_THỰC HÀNH 2";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private TextBox textBox1;
        private GroupBox groupBox2;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private CheckBox checkBox5;
        private Label label3;
        private Label label2;
        private NumericUpDown numericUpDown3;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private Label label6;
        private Label label5;
        private Label label4;
        private GroupBox groupBox3;
        private Button button2;
        private TextBox textBox2;
        private Button button1;
        private GroupBox groupBox4;
    }
}
