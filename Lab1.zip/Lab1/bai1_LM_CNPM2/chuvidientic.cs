﻿
using System;

namespace RetestConsole
{
    internal class chuvidientic
    {
        static void Main(string[] args)
        {
            // Đặt encoding để hiển thị tiếng Việt
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            double a, b;

            // Nhập chiều dài a
            do
            {
                Console.Write("Nhập vào chiều dài a (> 0): ");
                if (!double.TryParse(Console.ReadLine(), out a) || a <= 0)
                {
                    Console.WriteLine("❌ Giá trị không hợp lệ. Vui lòng nhập lại!");
                    a = -1;
                }
            } while (a <= 0);

            // Nhập chiều rộng b
            do
            {
                Console.Write("Nhập vào chiều rộng b (> 0): ");
                if (!double.TryParse(Console.ReadLine(), out b) || b <= 0)
                {
                    Console.WriteLine("❌ Giá trị không hợp lệ. Vui lòng nhập lại!");
                    b = -1;
                }
            } while (b <= 0);

            // Tính chu vi và diện tích
            double P = (a + b) * 2;
            double S = a * b;

            // Hiển thị kết quả
            Console.WriteLine("\n✅ Kết quả:");
            Console.WriteLine("Chu vi hình chữ nhật là: " + P);
            Console.WriteLine("Diện tích hình chữ nhật là: " + S);

            Console.WriteLine("\nNhấn phím bất kỳ để kết thúc...");
            Console.ReadKey();
            
        }
    }
}

