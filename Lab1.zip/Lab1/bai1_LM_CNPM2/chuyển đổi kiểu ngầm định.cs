﻿using System;

namespace DemoImplicitConversion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            // Khai báo biến kiểu short (2 byte)
            short x = 5;

            // Gán x cho y (int - 4 byte), C# sẽ tự động chuyển đổi
            int y = x;

            // Tiếp tục chuyển đổi ngầm định từ int -> long (8 byte)
            long z = y;

            // In ra kết quả
            Console.WriteLine("Giá trị x (short) = " + x);
            Console.WriteLine("Giá trị y (int)   = " + y);
            Console.WriteLine("Giá trị z (long)  = " + z);

            Console.WriteLine("\nNhấn phím bất kỳ để kết thúc...");
            Console.ReadKey();
        }
    }
}
