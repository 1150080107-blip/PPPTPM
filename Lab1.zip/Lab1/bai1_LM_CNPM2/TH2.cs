﻿using System;

namespace TimMax2So
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Nhập dữ liệu
            Console.Write("Nhập vào số nguyên a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhập vào số nguyên b: ");
            int b = Convert.ToInt32(Console.ReadLine());

            // Tìm số lớn hơn (dùng if...else)
            int max;
            if (a > b)
            {
                max = a;   // nếu a lớn hơn b
            }
            else
            {
                max = b;   // nếu b lớn hơn hoặc bằng a
            }

            // Hiển thị kết quả
            Console.WriteLine("👉 Số lớn hơn trong 2 số là: " + max);

            Console.ReadKey();
        }
    }
}
