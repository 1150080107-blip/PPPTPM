﻿using System;

class Program
{
    static void Main()
    {
        // Nhập số phần tử mảng
        Console.Write("Nhap so phan tu cua mang: ");
        int n = Convert.ToInt32(Console.ReadLine());

        int[] arr = new int[n];

        // Nhập các phần tử mảng
        for (int i = 0; i < n; i++)
        {
            Console.Write("Nhap phan tu arr[{0}]: ", i);
            arr[i] = Convert.ToInt32(Console.ReadLine());
        }

        // Tính tổng
        int sum = 0;
        for (int i = 0; i < n; i++)
        {
            sum += arr[i];
        }

        // Hiển thị kết quả
        Console.WriteLine("Tong cac phan tu trong mang = {0}", sum);
    }
}
