﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        // Đọc dữ liệu từ file input_array.txt
        string inputPath = "input_array.txt";
        if (!File.Exists(inputPath))
        {
            Console.WriteLine("❌ File {0} khong ton tai!", inputPath);
            return;
        }

        string[] data = File.ReadAllText(inputPath).Split(
            new char[] { ' ', '\n', '\r', '\t' },
            StringSplitOptions.RemoveEmptyEntries
        );

        int n = data.Length;
        int[] arr = new int[n];

        for (int i = 0; i < n; i++)
        {
            arr[i] = Convert.ToInt32(data[i]);
        }

        // Selection Sort
        for (int i = 0; i < n - 1; i++)
        {
            int minIndex = i;
            for (int j = i + 1; j < n; j++)
            {
                if (arr[j] < arr[minIndex])
                {
                    minIndex = j;
                }
            }

            // Hoán đổi
            int temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;
        }

        // Hiển thị kết quả
        Console.WriteLine("Mang sau khi sap xep tang dan:");
        foreach (int x in arr)
        {
            Console.Write(x + " ");
        }
        Console.WriteLine();

        // Lưu kết quả ra file output_array.txt
        string outputPath = "output_array.txt";
        File.WriteAllText(outputPath, string.Join(" ", arr));
        Console.WriteLine("\n✅ Ket qua da duoc luu vao {0}", outputPath);
    }
}
