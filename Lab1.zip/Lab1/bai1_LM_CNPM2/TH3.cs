﻿using System;

namespace SoNgayTrongThang
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Nhập dữ liệu
            Console.Write("Nhập vào năm: ");
            int nam = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhập vào tháng (1-12): ");
            int thang = Convert.ToInt32(Console.ReadLine());

            // Tìm số ngày trong tháng
            switch (thang)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    Console.WriteLine("👉 Tháng {0} năm {1} có 31 ngày.", thang, nam);
                    break;

                case 4:
                case 6:
                case 9:
                case 11:
                    Console.WriteLine("👉 Tháng {0} năm {1} có 30 ngày.", thang, nam);
                    break;

                case 2:
                    if ((nam % 400 == 0) || ((nam % 4 == 0) && (nam % 100 != 0)))
                    {
                        Console.WriteLine("👉 Tháng 2 năm {0} có 29 ngày (năm nhuận).", nam);
                    }
                    else
                    {
                        Console.WriteLine("👉 Tháng 2 năm {0} có 28 ngày.", nam);
                    }
                    break;

                default:
                    Console.WriteLine("❌ Tháng không hợp lệ! Vui lòng nhập 1-12.");
                    break;
            }

            Console.ReadKey();
        }
    }
}
