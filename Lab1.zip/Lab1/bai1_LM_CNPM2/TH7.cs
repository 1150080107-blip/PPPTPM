﻿using System;

class Program
{
    static void Main()
    {
        // Nhập dữ liệu
        Console.Write("Nhap vao do dai canh a: ");
        double a = Convert.ToDouble(Console.ReadLine());

        Console.Write("Nhap vao do dai canh b: ");
        double b = Convert.ToDouble(Console.ReadLine());

        Console.Write("Nhap vao do dai canh c: ");
        double c = Convert.ToDouble(Console.ReadLine());

        // Kiểm tra điều kiện tạo thành tam giác
        if (a + b > c && a + c > b && b + c > a)
        {
            // Tính chu vi
            double P = a + b + c;

            // Tính diện tích (công thức Heron)
            double p = P / 2;
            double S = Math.Sqrt(p * (p - a) * (p - b) * (p - c));

            Console.WriteLine("Ba doan thang lap thanh mot tam giac.");
            Console.WriteLine("Chu vi tam giac = {0}", P);
            Console.WriteLine("Dien tich tam giac = {0}", S);
        }
        else
        {
            Console.WriteLine("Ba doan thang khong lap thanh tam giac.");
        }
    }
}
