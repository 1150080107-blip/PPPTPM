﻿using System;

class Program
{
    static void Main()
    {
        // Mảng đã sắp xếp sẵn
        int[] arr = { 1, 3, 5, 7, 9 };
        int n = arr.Length;

        Console.WriteLine("Mang hien tai:");
        foreach (int a in arr)
        {
            Console.Write(a + " ");
        }
        Console.WriteLine();

        // Nhập số cần chèn
        Console.Write("Nhap vao so nguyen can chen: ");
        int x = Convert.ToInt32(Console.ReadLine());

        // Tạo mảng mới lớn hơn 1 phần tử
        int[] newArr = new int[n + 1];
        bool inserted = false;
        int j = 0;

        for (int i = 0; i < n; i++)
        {
            if (!inserted && x < arr[i])
            {
                newArr[j++] = x;
                inserted = true;
            }
            newArr[j++] = arr[i];
        }

        // Nếu x lớn nhất thì thêm cuối
        if (!inserted)
        {
            newArr[j] = x;
        }

        // In mảng mới
        Console.WriteLine("Mang sau khi chen:");
        foreach (int a in newArr)
        {
            Console.Write(a + " ");
        }
        Console.WriteLine();
    }
}
