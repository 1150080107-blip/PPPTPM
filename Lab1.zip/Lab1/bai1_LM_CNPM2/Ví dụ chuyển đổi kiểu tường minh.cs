﻿using System;

namespace DemoExplicitConversion
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Đặt encoding để nhập/xuất tiếng Việt (nếu cần)
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Nhập giá trị kiểu int
            Console.Write("Nhập một số nguyên y (int): ");
            int y = int.Parse(Console.ReadLine());  // ép kiểu chuỗi nhập vào thành int

            // Khai báo biến short
            short x;

            // Ép kiểu tường minh
            x = (short)y;

            // Hiển thị kết quả
            Console.WriteLine("\n✅ Kết quả:");
            Console.WriteLine("Giá trị y (int) = " + y);
            Console.WriteLine("Giá trị x (short) sau ép kiểu = " + x);

            Console.WriteLine("\nNhấn phím bất kỳ để kết thúc...");
            Console.ReadKey();
        }
    }
}
