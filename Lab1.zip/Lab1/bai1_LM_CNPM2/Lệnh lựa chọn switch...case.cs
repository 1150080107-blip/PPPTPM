﻿int luaChon;

Console.Write("Nhập lựa chọn (1-3): ");
luaChon = Convert.ToInt32(Console.ReadLine());

switch (luaChon)
{
    case 1:
        Console.WriteLine("Bạn chọn số 1");
        break;
    case 2:
        Console.WriteLine("Bạn chọn số 2");
        break;
    case 3:
        Console.WriteLine("Bạn chọn số 3");
        break;
    default:
        Console.WriteLine("❌ Lựa chọn không hợp lệ!");
        break;
}
