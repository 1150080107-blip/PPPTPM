﻿using System;

class Program
{
    static void Main()
    {
        // Nhập dữ liệu
        Console.Write("Nhap vao chieu dai: ");
        double dai = Convert.ToDouble(Console.ReadLine());

        Console.Write("Nhap vao chieu rong: ");
        double rong = Convert.ToDouble(Console.ReadLine());

        // Kiểm tra điều kiện dương
        if (dai <= 0 || rong <= 0)
        {
            Console.WriteLine("Chieu dai va chieu rong phai la so thuc duong!");
        }
        else
        {
            // Tính chu vi và diện tích
            double chuVi = 2 * (dai + rong);
            double dienTich = dai * rong;

            // Xuất kết quả
            Console.WriteLine("Chu vi hinh chu nhat = {0}", chuVi);
            Console.WriteLine("Dien tich hinh chu nhat = {0}", dienTich);
        }
    }
}
