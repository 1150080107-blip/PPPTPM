﻿using System;

namespace DemoInput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            // Nhập số nguyên
            Console.Write("Nhập một số nguyên a: ");
            int a = Convert.ToInt32(Console.ReadLine());

            // Nhập số thực
            Console.Write("Nhập một số thực b: ");
            double b = Convert.ToDouble(Console.ReadLine());

            // Nhập chuỗi
            Console.Write("Nhập tên của bạn: ");
            string name = Console.ReadLine();

            // In kết quả
            Console.WriteLine("\n✅ Kết quả:");
            Console.WriteLine("Số nguyên a = " + a);
            Console.WriteLine("Số thực b = " + b);
            Console.WriteLine("Xin chào, " + name + "!");

            Console.ReadKey();
        }
    }
}
