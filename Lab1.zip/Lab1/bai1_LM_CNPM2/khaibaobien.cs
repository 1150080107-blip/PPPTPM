﻿using System;

namespace DemoVariables
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Khai báo biến số nguyên
            int a = 1, b = 2;
            int a1, a2 = 3;

            // Khai báo biến chuỗi
            string diaChi = "anoi";

            // Khai báo biến số thực
            float thanhTien = 456.9F;   // F để xác định kiểu float
            double pi = 3.14159;        // double chính xác hơn float

            // Khai báo biến logic
            bool kt = true;

            // Khai báo biến ký tự
            char ch = 'a';

            // Khai báo biến chuỗi
            string s1 = "timoday";
            string s2 = ".edu.vn";

            // In ra giá trị biến
            Console.WriteLine("a = " + a);
            Console.WriteLine("b = " + b);
            Console.WriteLine("a2 = " + a2);
            Console.WriteLine("Địa chỉ: " + diaChi);
            Console.WriteLine("Thành tiền: " + thanhTien);
            Console.WriteLine("kt = " + kt);
            Console.WriteLine("Ký tự: " + ch);
            Console.WriteLine("Chuỗi ghép: " + s1 + s2);

            Console.ReadKey();
        }
    }
}
