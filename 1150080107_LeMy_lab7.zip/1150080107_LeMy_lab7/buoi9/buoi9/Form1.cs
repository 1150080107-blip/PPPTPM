﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace buoi9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // 🔹 Chuỗi kết nối (chỉnh đúng đường dẫn file .mdf của bạn)
        string strCon = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\admin\Downloads\buoi9\buoi9\buoi9\QuanLyBanSach.mdf;Integrated Security=True";


        SqlConnection sqlCon = null;
        SqlDataAdapter adapter = null;
        DataSet ds = null;
        int vt = -1;

        private void MoKetNoi()
        {
            if (sqlCon == null)
                sqlCon = new SqlConnection(strCon);
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
        }

        private void DongKetNoi()
        {
            if (sqlCon != null && sqlCon.State == ConnectionState.Open)
                sqlCon.Close();
        }

        // 🔸 Hiển thị dữ liệu
        private void HienThiDuLieu(DataGridView dgv)
        {
            MoKetNoi();
            string query = "SELECT * FROM NhaXuatBan";
            adapter = new SqlDataAdapter(query, sqlCon);
            SqlCommandBuilder builder = new SqlCommandBuilder(adapter);
            ds = new DataSet();
            adapter.Fill(ds, "tblNhaXuatBan");
            dgv.DataSource = ds.Tables["tblNhaXuatBan"];
            DongKetNoi();
        }

        // 🔸 Khi load form
        private void Form1_Load(object sender, EventArgs e)
        {
            HienThiDuLieu(dgvDanhSach);
            HienThiDuLieu(dgvSua);
            HienThiDuLieu(dgvXoa);
        }

        // ================= TAB 1: HIỂN THỊ =================
        private void btnHienThi_Click(object sender, EventArgs e)
        {
            HienThiDuLieu(dgvDanhSach);
        }

        // ================= TAB 2: THÊM DỮ LIỆU =================
        private void btnThemDL_Click(object sender, EventArgs e)
        {
            try
            {
                DataRow row = ds.Tables["tblNhaXuatBan"].NewRow();
                row["MaXB"] = txtMaXB.Text.Trim();
                row["TenXB"] = txtTenXB.Text.Trim();
                row["DiaChi"] = txtDiaChi.Text.Trim();
                ds.Tables["tblNhaXuatBan"].Rows.Add(row);

                int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("✅ Thêm dữ liệu thành công!");
                    HienThiDuLieu(dgvDanhSach);
                    HienThiDuLieu(dgvSua);
                    HienThiDuLieu(dgvXoa);
                    txtMaXB.Clear();
                    txtTenXB.Clear();
                    txtDiaChi.Clear();
                }
                else MessageBox.Show("❌ Thêm dữ liệu thất bại!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        // ================= TAB 3: CẬP NHẬT =================
        private void dgvSua_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex;
            if (vt == -1) return;

            DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];
            txtMaXB_Sua.Text = row["MaXB"].ToString();
            txtTenXB_Sua.Text = row["TenXB"].ToString();
            txtDiaChi_Sua.Text = row["DiaChi"].ToString();
        }

        private void btnSuaDL_Click(object sender, EventArgs e)
        {
            if (vt == -1)
            {
                MessageBox.Show("⚠️ Hãy chọn dòng cần sửa trong bảng!");
                return;
            }

            DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];
            row.BeginEdit();
            row["MaXB"] = txtMaXB_Sua.Text.Trim();
            row["TenXB"] = txtTenXB_Sua.Text.Trim();
            row["DiaChi"] = txtDiaChi_Sua.Text.Trim();
            row.EndEdit();

            int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);
            if (kq > 0)
            {
                MessageBox.Show("✅ Cập nhật thành công!");
                HienThiDuLieu(dgvDanhSach);
                HienThiDuLieu(dgvSua);
                HienThiDuLieu(dgvXoa);
            }
            else MessageBox.Show("❌ Cập nhật thất bại!");
        }

        // ================= TAB 4: XÓA =================
        private void dgvXoa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            vt = e.RowIndex;
        }

        private void btnXoaDL_Click(object sender, EventArgs e)
        {
            if (vt == -1)
            {
                MessageBox.Show("⚠️ Hãy chọn dòng cần xóa!");
                return;
            }

            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa dòng này không?",
                "Cảnh báo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                DataRow row = ds.Tables["tblNhaXuatBan"].Rows[vt];
                row.Delete();
                int kq = adapter.Update(ds.Tables["tblNhaXuatBan"]);
                if (kq > 0)
                {
                    MessageBox.Show("🗑️ Xóa thành công!");
                    HienThiDuLieu(dgvDanhSach);
                    HienThiDuLieu(dgvSua);
                    HienThiDuLieu(dgvXoa);
                }
                else MessageBox.Show("❌ Xóa thất bại!");
            }
        }
    }
}
