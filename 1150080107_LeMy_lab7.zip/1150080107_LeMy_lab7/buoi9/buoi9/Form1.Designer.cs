﻿namespace buoi9
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabMain = new System.Windows.Forms.TabControl();
            this.tabHienThi = new System.Windows.Forms.TabPage();
            this.btnHienThi = new System.Windows.Forms.Button();
            this.dgvDanhSach = new System.Windows.Forms.DataGridView();
            this.tabThem = new System.Windows.Forms.TabPage();
            this.btnThemDL = new System.Windows.Forms.Button();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtTenXB = new System.Windows.Forms.TextBox();
            this.txtMaXB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabSua = new System.Windows.Forms.TabPage();
            this.btnSuaDL = new System.Windows.Forms.Button();
            this.txtDiaChi_Sua = new System.Windows.Forms.TextBox();
            this.txtTenXB_Sua = new System.Windows.Forms.TextBox();
            this.txtMaXB_Sua = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvSua = new System.Windows.Forms.DataGridView();
            this.tabXoa = new System.Windows.Forms.TabPage();
            this.btnXoaDL = new System.Windows.Forms.Button();
            this.dgvXoa = new System.Windows.Forms.DataGridView();
            this.tabMain.SuspendLayout();
            this.tabHienThi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSach)).BeginInit();
            this.tabThem.SuspendLayout();
            this.tabSua.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSua)).BeginInit();
            this.tabXoa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXoa)).BeginInit();
            this.SuspendLayout();
            // 
            // tabMain
            // 
            this.tabMain.Controls.Add(this.tabHienThi);
            this.tabMain.Controls.Add(this.tabThem);
            this.tabMain.Controls.Add(this.tabSua);
            this.tabMain.Controls.Add(this.tabXoa);
            this.tabMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabMain.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabMain.Location = new System.Drawing.Point(0, 0);
            this.tabMain.Name = "tabMain";
            this.tabMain.SelectedIndex = 0;
            this.tabMain.Size = new System.Drawing.Size(800, 500);
            this.tabMain.TabIndex = 0;
            // 
            // tabHienThi
            // 
            this.tabHienThi.Controls.Add(this.btnHienThi);
            this.tabHienThi.Controls.Add(this.dgvDanhSach);
            this.tabHienThi.Location = new System.Drawing.Point(4, 37);
            this.tabHienThi.Name = "tabHienThi";
            this.tabHienThi.Padding = new System.Windows.Forms.Padding(3);
            this.tabHienThi.Size = new System.Drawing.Size(792, 459);
            this.tabHienThi.TabIndex = 0;
            this.tabHienThi.Text = "Hiển thị";
            this.tabHienThi.UseVisualStyleBackColor = true;
            // 
            // btnHienThi
            // 
            this.btnHienThi.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnHienThi.Location = new System.Drawing.Point(300, 20);
            this.btnHienThi.Name = "btnHienThi";
            this.btnHienThi.Size = new System.Drawing.Size(180, 40);
            this.btnHienThi.TabIndex = 1;
            this.btnHienThi.Text = "Hiển thị danh sách";
            this.btnHienThi.UseVisualStyleBackColor = true;
            this.btnHienThi.Click += new System.EventHandler(this.btnHienThi_Click);
            // 
            // dgvDanhSach
            // 
            this.dgvDanhSach.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDanhSach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSach.Location = new System.Drawing.Point(30, 80);
            this.dgvDanhSach.Name = "dgvDanhSach";
            this.dgvDanhSach.RowHeadersWidth = 51;
            this.dgvDanhSach.RowTemplate.Height = 29;
            this.dgvDanhSach.Size = new System.Drawing.Size(720, 360);
            this.dgvDanhSach.TabIndex = 0;
            // 
            // tabThem
            // 
            this.tabThem.Controls.Add(this.btnThemDL);
            this.tabThem.Controls.Add(this.txtDiaChi);
            this.tabThem.Controls.Add(this.txtTenXB);
            this.tabThem.Controls.Add(this.txtMaXB);
            this.tabThem.Controls.Add(this.label3);
            this.tabThem.Controls.Add(this.label2);
            this.tabThem.Controls.Add(this.label1);
            this.tabThem.Location = new System.Drawing.Point(4, 37);
            this.tabThem.Name = "tabThem";
            this.tabThem.Padding = new System.Windows.Forms.Padding(3);
            this.tabThem.Size = new System.Drawing.Size(792, 459);
            this.tabThem.TabIndex = 1;
            this.tabThem.Text = "Thêm dữ liệu";
            this.tabThem.UseVisualStyleBackColor = true;
            // 
            // btnThemDL
            // 
            this.btnThemDL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnThemDL.Location = new System.Drawing.Point(300, 240);
            this.btnThemDL.Name = "btnThemDL";
            this.btnThemDL.Size = new System.Drawing.Size(180, 45);
            this.btnThemDL.TabIndex = 6;
            this.btnThemDL.Text = "Thêm dữ liệu";
            this.btnThemDL.UseVisualStyleBackColor = true;
            this.btnThemDL.Click += new System.EventHandler(this.btnThemDL_Click);
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(220, 170);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(400, 34);
            this.txtDiaChi.TabIndex = 5;
            // 
            // txtTenXB
            // 
            this.txtTenXB.Location = new System.Drawing.Point(220, 120);
            this.txtTenXB.Name = "txtTenXB";
            this.txtTenXB.Size = new System.Drawing.Size(400, 34);
            this.txtTenXB.TabIndex = 4;
            // 
            // txtMaXB
            // 
            this.txtMaXB.Location = new System.Drawing.Point(220, 70);
            this.txtMaXB.Name = "txtMaXB";
            this.txtMaXB.Size = new System.Drawing.Size(400, 34);
            this.txtMaXB.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(130, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 28);
            this.label3.TabIndex = 2;
            this.label3.Text = "Địa chỉ:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(130, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 28);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tên XB:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(130, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mã XB:";
            // 
            // tabSua
            // 
            this.tabSua.Controls.Add(this.btnSuaDL);
            this.tabSua.Controls.Add(this.txtDiaChi_Sua);
            this.tabSua.Controls.Add(this.txtTenXB_Sua);
            this.tabSua.Controls.Add(this.txtMaXB_Sua);
            this.tabSua.Controls.Add(this.label6);
            this.tabSua.Controls.Add(this.label5);
            this.tabSua.Controls.Add(this.label4);
            this.tabSua.Controls.Add(this.dgvSua);
            this.tabSua.Location = new System.Drawing.Point(4, 37);
            this.tabSua.Name = "tabSua";
            this.tabSua.Padding = new System.Windows.Forms.Padding(3);
            this.tabSua.Size = new System.Drawing.Size(792, 459);
            this.tabSua.TabIndex = 2;
            this.tabSua.Text = "Cập nhật";
            this.tabSua.UseVisualStyleBackColor = true;
            // 
            // btnSuaDL
            // 
            this.btnSuaDL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnSuaDL.Location = new System.Drawing.Point(320, 190);
            this.btnSuaDL.Name = "btnSuaDL";
            this.btnSuaDL.Size = new System.Drawing.Size(150, 40);
            this.btnSuaDL.TabIndex = 7;
            this.btnSuaDL.Text = "Cập nhật";
            this.btnSuaDL.UseVisualStyleBackColor = true;
            this.btnSuaDL.Click += new System.EventHandler(this.btnSuaDL_Click);
            // 
            // txtDiaChi_Sua
            // 
            this.txtDiaChi_Sua.Location = new System.Drawing.Point(220, 140);
            this.txtDiaChi_Sua.Name = "txtDiaChi_Sua";
            this.txtDiaChi_Sua.Size = new System.Drawing.Size(400, 34);
            this.txtDiaChi_Sua.TabIndex = 6;
            // 
            // txtTenXB_Sua
            // 
            this.txtTenXB_Sua.Location = new System.Drawing.Point(220, 90);
            this.txtTenXB_Sua.Name = "txtTenXB_Sua";
            this.txtTenXB_Sua.Size = new System.Drawing.Size(400, 34);
            this.txtTenXB_Sua.TabIndex = 5;
            // 
            // txtMaXB_Sua
            // 
            this.txtMaXB_Sua.Location = new System.Drawing.Point(220, 40);
            this.txtMaXB_Sua.Name = "txtMaXB_Sua";
            this.txtMaXB_Sua.Size = new System.Drawing.Size(400, 34);
            this.txtMaXB_Sua.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(130, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 28);
            this.label6.TabIndex = 8;
            this.label6.Text = "Địa chỉ:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(130, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 28);
            this.label5.TabIndex = 9;
            this.label5.Text = "Tên XB:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(130, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 28);
            this.label4.TabIndex = 10;
            this.label4.Text = "Mã XB:";
            // 
            // dgvSua
            // 
            this.dgvSua.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvSua.ColumnHeadersHeight = 34;
            this.dgvSua.Location = new System.Drawing.Point(30, 250);
            this.dgvSua.Name = "dgvSua";
            this.dgvSua.RowHeadersWidth = 62;
            this.dgvSua.Size = new System.Drawing.Size(720, 200);
            this.dgvSua.TabIndex = 0;
            this.dgvSua.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvSua_CellClick);
            // 
            // tabXoa
            // 
            this.tabXoa.Controls.Add(this.btnXoaDL);
            this.tabXoa.Controls.Add(this.dgvXoa);
            this.tabXoa.Location = new System.Drawing.Point(4, 37);
            this.tabXoa.Name = "tabXoa";
            this.tabXoa.Padding = new System.Windows.Forms.Padding(3);
            this.tabXoa.Size = new System.Drawing.Size(792, 459);
            this.tabXoa.TabIndex = 3;
            this.tabXoa.Text = "Xóa dữ liệu";
            this.tabXoa.UseVisualStyleBackColor = true;
            // 
            // btnXoaDL
            // 
            this.btnXoaDL.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.btnXoaDL.Location = new System.Drawing.Point(320, 20);
            this.btnXoaDL.Name = "btnXoaDL";
            this.btnXoaDL.Size = new System.Drawing.Size(150, 40);
            this.btnXoaDL.TabIndex = 1;
            this.btnXoaDL.Text = "Xóa dữ liệu";
            this.btnXoaDL.UseVisualStyleBackColor = true;
            this.btnXoaDL.Click += new System.EventHandler(this.btnXoaDL_Click);
            // 
            // dgvXoa
            // 
            this.dgvXoa.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXoa.ColumnHeadersHeight = 34;
            this.dgvXoa.Location = new System.Drawing.Point(30, 80);
            this.dgvXoa.Name = "dgvXoa";
            this.dgvXoa.RowHeadersWidth = 62;
            this.dgvXoa.Size = new System.Drawing.Size(720, 350);
            this.dgvXoa.TabIndex = 0;
            this.dgvXoa.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvXoa_CellClick);
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(800, 500);
            this.Controls.Add(this.tabMain);
            this.Name = "Form1";
            this.Text = "15_LêMy_Quản lý Nhà Xuất Bản - CRUD 4 chức năng";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabMain.ResumeLayout(false);
            this.tabHienThi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSach)).EndInit();
            this.tabThem.ResumeLayout(false);
            this.tabThem.PerformLayout();
            this.tabSua.ResumeLayout(false);
            this.tabSua.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSua)).EndInit();
            this.tabXoa.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvXoa)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMain;
        private System.Windows.Forms.TabPage tabHienThi;
        private System.Windows.Forms.TabPage tabThem;
        private System.Windows.Forms.TabPage tabSua;
        private System.Windows.Forms.TabPage tabXoa;
        private System.Windows.Forms.Button btnHienThi;
        private System.Windows.Forms.DataGridView dgvDanhSach;
        private System.Windows.Forms.Button btnThemDL;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtTenXB;
        private System.Windows.Forms.TextBox txtMaXB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvSua;
        private System.Windows.Forms.Button btnSuaDL;
        private System.Windows.Forms.TextBox txtDiaChi_Sua;
        private System.Windows.Forms.TextBox txtTenXB_Sua;
        private System.Windows.Forms.TextBox txtMaXB_Sua;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnXoaDL;
        private System.Windows.Forms.DataGridView dgvXoa;
    }
}
