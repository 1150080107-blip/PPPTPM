﻿namespace LMy_1150080107_TH7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>   
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtMaSV = new TextBox();
            txtTenSV = new TextBox();
            cbGioiTinh = new ComboBox();
            dtpNgaySinh = new DateTimePicker();
            txtQueQuan = new TextBox();
            txtMaLop = new TextBox();
            btnThemSinhVien = new Button();
            groupBox2 = new GroupBox();
            lsvDanhSachSV = new ListView();
            colMaSV = new ColumnHeader();
            colTenSV = new ColumnHeader();
            colGioiTinh = new ColumnHeader();
            colNgaySinh = new ColumnHeader();
            colQueQuan = new ColumnHeader();
            colMaLop = new ColumnHeader();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtMaSV);
            groupBox1.Controls.Add(txtTenSV);
            groupBox1.Controls.Add(cbGioiTinh);
            groupBox1.Controls.Add(dtpNgaySinh);
            groupBox1.Controls.Add(txtQueQuan);
            groupBox1.Controls.Add(txtMaLop);
            groupBox1.Controls.Add(btnThemSinhVien);
            groupBox1.Location = new Point(12, 35);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(280, 300);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Nhập thông tin:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(10, 185);
            label6.Name = "label6";
            label6.Size = new Size(72, 25);
            label6.TabIndex = 0;
            label6.Text = "Mã lớp:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(10, 155);
            label5.Name = "label5";
            label5.Size = new Size(94, 25);
            label5.TabIndex = 1;
            label5.Text = "Quê quán:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(10, 125);
            label4.Name = "label4";
            label4.Size = new Size(95, 25);
            label4.TabIndex = 2;
            label4.Text = "Ngày sinh:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 95);
            label3.Name = "label3";
            label3.Size = new Size(82, 25);
            label3.TabIndex = 3;
            label3.Text = "Giới tính:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 65);
            label2.Name = "label2";
            label2.Size = new Size(116, 25);
            label2.TabIndex = 4;
            label2.Text = "Tên sinh viên:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(10, 35);
            label1.Name = "label1";
            label1.Size = new Size(115, 25);
            label1.TabIndex = 5;
            label1.Text = "Mã sinh viên:";
            // 
            // txtMaSV
            // 
            txtMaSV.Location = new Point(100, 32);
            txtMaSV.Name = "txtMaSV";
            txtMaSV.Size = new Size(150, 31);
            txtMaSV.TabIndex = 6;
            // 
            // txtTenSV
            // 
            txtTenSV.Location = new Point(100, 62);
            txtTenSV.Name = "txtTenSV";
            txtTenSV.Size = new Size(150, 31);
            txtTenSV.TabIndex = 7;
            // 
            // cbGioiTinh
            // 
            cbGioiTinh.DropDownStyle = ComboBoxStyle.DropDownList;
            cbGioiTinh.Location = new Point(100, 92);
            cbGioiTinh.Name = "cbGioiTinh";
            cbGioiTinh.Size = new Size(150, 33);
            cbGioiTinh.TabIndex = 8;
            // 
            // dtpNgaySinh
            // 
            dtpNgaySinh.Location = new Point(100, 122);
            dtpNgaySinh.Name = "dtpNgaySinh";
            dtpNgaySinh.Size = new Size(150, 31);
            dtpNgaySinh.TabIndex = 9;
            // 
            // txtQueQuan
            // 
            txtQueQuan.Location = new Point(100, 152);
            txtQueQuan.Name = "txtQueQuan";
            txtQueQuan.Size = new Size(150, 31);
            txtQueQuan.TabIndex = 10;
            // 
            // txtMaLop
            // 
            txtMaLop.Location = new Point(100, 182);
            txtMaLop.Name = "txtMaLop";
            txtMaLop.Size = new Size(150, 31);
            txtMaLop.TabIndex = 11;
            // 
            // btnThemSinhVien
            // 
            btnThemSinhVien.Location = new Point(100, 220);
            btnThemSinhVien.Name = "btnThemSinhVien";
            btnThemSinhVien.Size = new Size(150, 30);
            btnThemSinhVien.TabIndex = 12;
            btnThemSinhVien.Text = "Thêm sinh viên";
            btnThemSinhVien.UseVisualStyleBackColor = true;
            btnThemSinhVien.Click += btnThemSinhVien_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lsvDanhSachSV);
            groupBox2.Location = new Point(310, 35);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(540, 300);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách sinh viên:";
            // 
            // lsvDanhSachSV
            // 
            lsvDanhSachSV.Columns.AddRange(new ColumnHeader[] { colMaSV, colTenSV, colGioiTinh, colNgaySinh, colQueQuan, colMaLop });
            lsvDanhSachSV.FullRowSelect = true;
            lsvDanhSachSV.GridLines = true;
            lsvDanhSachSV.Location = new Point(10, 25);
            lsvDanhSachSV.Name = "lsvDanhSachSV";
            lsvDanhSachSV.Size = new Size(520, 260);
            lsvDanhSachSV.TabIndex = 0;
            lsvDanhSachSV.UseCompatibleStateImageBehavior = false;
            lsvDanhSachSV.View = View.Details;
            lsvDanhSachSV.SelectedIndexChanged += lsvDanhSachSV_SelectedIndexChanged;
            // 
            // colMaSV
            // 
            colMaSV.Text = "Mã SV";
            // 
            // colTenSV
            // 
            colTenSV.Text = "Tên SV";
            // 
            // colGioiTinh
            // 
            colGioiTinh.Text = "Giới tính";
            // 
            // colNgaySinh
            // 
            colNgaySinh.Text = "Ngày sinh";
            // 
            // colQueQuan
            // 
            colQueQuan.Text = "Quê quán";
            // 
            // colMaLop
            // 
            colMaLop.Text = "Mã lớp";
            // 
            // Form1
            // 
            ClientSize = new Size(870, 360);
            Controls.Add(groupBox1);
            Controls.Add(groupBox2);
            Name = "Form1";
            Text = "Thêm dữ liệu không dùng Parameter";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMaSV;
        private System.Windows.Forms.TextBox txtTenSV;
        private System.Windows.Forms.ComboBox cbGioiTinh;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.TextBox txtQueQuan;
        private System.Windows.Forms.TextBox txtMaLop;
        private System.Windows.Forms.Button btnThemSinhVien;
        private System.Windows.Forms.ListView lsvDanhSachSV;
        private System.Windows.Forms.ColumnHeader colMaSV;
        private System.Windows.Forms.ColumnHeader colTenSV;
        private System.Windows.Forms.ColumnHeader colGioiTinh;
        private System.Windows.Forms.ColumnHeader colNgaySinh;
        private System.Windows.Forms.ColumnHeader colQueQuan;
        private System.Windows.Forms.ColumnHeader colMaLop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}
